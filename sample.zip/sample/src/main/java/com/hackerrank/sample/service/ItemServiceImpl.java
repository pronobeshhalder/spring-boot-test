package com.hackerrank.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.hackerrank.sample.model.Item;
import com.hackerrank.sample.repository.ItemRepository;

@Service("itemService")
public class ItemServiceImpl extends AbstractService<Item, Long>{
	@Autowired
	private ItemRepository itemRepository;

	@Override
	public JpaRepository<Item, Long> getReposotiry() {
		return itemRepository;
	}

}
