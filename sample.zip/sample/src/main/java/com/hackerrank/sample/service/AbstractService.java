package com.hackerrank.sample.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hackerrank.sample.exception.BadResourceRequestException;
import com.hackerrank.sample.exception.NoSuchResourceFoundException;
import com.hackerrank.sample.model.Customer;
import com.hackerrank.sample.model.EntityModel;

public abstract class AbstractService<T extends EntityModel<ID>,ID extends Serializable> implements Service<T,ID> {

	@Override
	public void deleteAll() {
		getReposotiry().deleteAllInBatch();
		
	}

	@Override
	public void deleteById(ID id) {
		getReposotiry().delete(id);
		
	}

	@Override
	public void create(T entity) {
		T existingModel = getReposotiry().findOne(entity.getPrimaryKey());
		if (existingModel != null) {
			throw new BadResourceRequestException("Entity with same id exists.");
		}

		getReposotiry().save(entity);
		
	}

	@Override
	public T getById(ID id) {
		T entity = getReposotiry().findOne(id);

		if (entity == null) {
			throw new NoSuchResourceFoundException("No Entity with given id found.");
		}
		return entity;
	}

	@Override
	public List<T> getAll() {
		// TODO Auto-generated method stub
		return getReposotiry().findAll();
	}

	@Override
	public void update(T entity) {
		T ent =  getReposotiry().findOne(entity.getPrimaryKey());

		if (ent == null) {
			throw new NoSuchResourceFoundException("No Entity with given id found.");
		}
		getReposotiry().save(entity);
		
	}
	
	public abstract JpaRepository<T, ID> getReposotiry();

}
