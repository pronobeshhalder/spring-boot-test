package com.hackerrank.sample.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Vendor implements EntityModel<Long> {
	@Id
	private Long vendorId;
	private String vendorName;
	private Long vendorContactNo;
	private String vendorEmail;
	private String vendorUsername;
	private String vendorAddress;
	
	public Vendor() {
		
	}

	public Long getVendorId() {
		return vendorId;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Long getVendorContactNo() {
		return vendorContactNo;
	}

	public void setVendorContactNo(Long vendorContactNo) {
		this.vendorContactNo = vendorContactNo;
	}

	public String getVendorEmail() {
		return vendorEmail;
	}

	public void setVendorEmail(String vendorEmail) {
		this.vendorEmail = vendorEmail;
	}

	public String getVendorUsername() {
		return vendorUsername;
	}

	public void setVendorUsername(String vendorUsername) {
		this.vendorUsername = vendorUsername;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	@Transient
	@JsonIgnore
	public Long getPrimaryKey() {
		// TODO Auto-generated method stub
		return getVendorId();
	}

}
