package com.hackerrank.sample.service;

import java.io.Serializable;
import java.util.List;

import com.hackerrank.sample.model.Customer;
import com.hackerrank.sample.model.EntityModel;

public interface Service<T extends EntityModel<ID>,ID extends Serializable> {
    void deleteAll();
    void deleteById(ID id);
    void create(T entity);
    T getById(ID id);
    List<T> getAll();
    void update(T entity);
}
