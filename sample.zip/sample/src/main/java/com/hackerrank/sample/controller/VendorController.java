package com.hackerrank.sample.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.sample.model.Customer;
import com.hackerrank.sample.model.Vendor;
import com.hackerrank.sample.service.Service;

@RestController
public class VendorController {
    @Autowired
    private Service<Vendor, Long> vendorService;
    //private CustomerService customerService;

    @RequestMapping(value = "/vendor", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.CREATED)
    public void createNewCustomer(@RequestBody @Valid Vendor vendor) {
    	//vendorService.createCustomer(customer);
    	vendorService.create(vendor);
    }

    @RequestMapping(value = "/vendor", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteAllCustomers() {
    	//vendorService.deleteAllCustomers();
    	vendorService.deleteAll();
    }

    @RequestMapping(value = "/vendor/{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteCustomerById(@PathVariable Long id) {
    	//vendorService.deleteCustomerById(id);
    	vendorService.deleteById(id);
    }
    
    @RequestMapping(value = "/vendor", method = RequestMethod.PUT, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public Vendor updateCustomer(@RequestBody @Valid Vendor vendor) {
    	//vendorService.updateCustomer(customer);
    	vendorService.update(vendor);
    	return vendor;
    }

    @RequestMapping(value = "/vendor", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Vendor> getAllCustomers() {
        //return customerService.getAllCustomers();
    	return vendorService.getAll();
    }

    @RequestMapping(value = "/vendor/{id}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Vendor getCustomerById(@PathVariable Long id) {
       // return customerService.getCustomerById(id);
    	return vendorService.getById(id);
    }
}
