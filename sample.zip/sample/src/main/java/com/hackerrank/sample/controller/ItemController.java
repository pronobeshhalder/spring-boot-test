package com.hackerrank.sample.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.sample.model.Item;
import com.hackerrank.sample.service.Service;

@RestController
public class ItemController {
    @Autowired
    private Service<Item, Long> itemService;
    //private CustomerService customerService;

    @RequestMapping(value = "/item", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.CREATED)
    public void createNewCustomer(@RequestBody @Valid Item item) {
    	//itemService.createCustomer(customer);
    	itemService.create(item);
    }

    @RequestMapping(value = "/item", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteAllCustomers() {
    	//itemService.deleteAllCustomers();
    	itemService.deleteAll();
    }

    @RequestMapping(value = "/item/{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteCustomerById(@PathVariable Long id) {
    	//itemService.deleteCustomerById(id);
    	itemService.deleteById(id);
    }
    
    @RequestMapping(value = "/item", method = RequestMethod.PUT, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public Item updateCustomer(@RequestBody @Valid Item item) {
    	//itemService.updateCustomer(customer);
    	itemService.update(item);
    	return item;
    }

    @RequestMapping(value = "/item", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Item> getAllCustomers() {
        //return customerService.getAllCustomers();
    	return itemService.getAll();
    }

    @RequestMapping(value = "/item/{id}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Item getCustomerById(@PathVariable Long id) {
       // return customerService.getCustomerById(id);
    	return itemService.getById(id);
    }
}
