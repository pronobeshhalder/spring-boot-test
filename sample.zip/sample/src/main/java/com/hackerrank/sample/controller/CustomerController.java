package com.hackerrank.sample.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.sample.model.Customer;
import com.hackerrank.sample.service.Service;

@RestController
public class CustomerController {
    @Autowired
    private Service<Customer, Long> customerService;
    //private CustomerService customerService;

    @RequestMapping(value = "/customer", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.CREATED)
    public void createNewCustomer(@RequestBody @Valid Customer customer) {
    	//customerService.createCustomer(customer);
    	customerService.create(customer);
    }

    @RequestMapping(value = "/customer", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteAllCustomers() {
    	//customerService.deleteAllCustomers();
    	customerService.deleteAll();
    }

    @RequestMapping(value = "/customer/{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteCustomerById(@PathVariable Long id) {
    	//customerService.deleteCustomerById(id);
    	customerService.deleteById(id);
    }
    
    @RequestMapping(value = "/customer", method = RequestMethod.PUT, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public Customer updateCustomer(@RequestBody @Valid Customer customer) {
    	//customerService.updateCustomer(customer);
    	customerService.update(customer);
    	return customer;
    }

    @RequestMapping(value = "/customer", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Customer> getAllCustomers() {
        //return customerService.getAllCustomers();
    	return customerService.getAll();
    }

    @RequestMapping(value = "/customer/{id}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Customer getCustomerById(@PathVariable Long id) {
       // return customerService.getCustomerById(id);
    	return customerService.getById(id);
    }
}
