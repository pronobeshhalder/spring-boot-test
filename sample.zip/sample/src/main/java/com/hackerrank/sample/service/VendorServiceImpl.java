package com.hackerrank.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.hackerrank.sample.model.Vendor;
import com.hackerrank.sample.repository.VendorRepository;

@Service("vendorService")
public class VendorServiceImpl extends AbstractService<Vendor, Long>{
	@Autowired
	private VendorRepository vendorRepository;

	@Override
	public JpaRepository<Vendor, Long> getReposotiry() {
		return vendorRepository;
	}

}
