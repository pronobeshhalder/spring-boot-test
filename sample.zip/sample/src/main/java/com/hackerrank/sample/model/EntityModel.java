package com.hackerrank.sample.model;

import java.io.Serializable;

public interface EntityModel<T> extends Serializable {
	public T getPrimaryKey();
}
