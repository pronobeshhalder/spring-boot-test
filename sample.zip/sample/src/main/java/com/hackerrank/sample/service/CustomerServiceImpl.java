package com.hackerrank.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.hackerrank.sample.exception.BadResourceRequestException;
import com.hackerrank.sample.exception.NoSuchResourceFoundException;
import com.hackerrank.sample.model.Customer;
import com.hackerrank.sample.repository.CustomerRepository;

@Service("customerService")
public class CustomerServiceImpl extends AbstractService<Customer, Long> {
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public JpaRepository<Customer, Long> getReposotiry() {
		// TODO Auto-generated method stub
		return customerRepository;
	}

	/*@Override
	public void deleteAllCustomers() {
		customerRepository.deleteAllInBatch();

	}

	@Override
	public void deleteCustomerById(Long id) {
		customerRepository.delete(id);

	}

	@Override
	public void createCustomer(Customer customer) {
		Customer existingModel = customerRepository.findOne(customer.getCustomerId());
		if (existingModel != null) {
			throw new BadResourceRequestException("Customer with same id exists.");
		}

		customerRepository.save(customer);

	}

	@Override
	public Customer getCustomerById(Long id) {
		Customer customer = customerRepository.findOne(id);

		if (customer == null) {
			throw new NoSuchResourceFoundException("No Customer with given id found.");
		}

		return customer;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public void updateCustomer(Customer customer) {
		Customer cust = customerRepository.findOne(customer.getCustomerId());

		if (cust == null) {
			throw new NoSuchResourceFoundException("No Customer with given id found.");
		}
		customerRepository.save(customer);
		
	}*/
}
