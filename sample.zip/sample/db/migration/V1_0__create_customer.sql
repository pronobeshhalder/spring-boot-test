CREATE TABLE IF NOT EXISTS `customer` (
 
    `customer_Id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `customer_Name` varchar(20),
    `contact_Number` int,
    `address` varchar(20),
    `gender` varchar(10)
 
)ENGINE=InnoDB DEFAULT CHARSET=UTF8;