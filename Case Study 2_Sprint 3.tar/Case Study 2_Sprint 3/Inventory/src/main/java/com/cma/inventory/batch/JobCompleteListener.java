package com.cma.inventory.batch;


import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.cma.inventory.model.Inventory;

@Component
public class JobCompleteListener extends JobExecutionListenerSupport {

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public JobCompleteListener(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
			jdbcTemplate.query("SELECT skuId,inventoryOnHand FROM Inventory",
				(rs, row) -> new Inventory(
					rs.getLong(1),
					rs.getInt(2))
			).forEach(Inventory -> System.out.println("Found <" + Inventory + "> in the database."));
		}
	}
}
