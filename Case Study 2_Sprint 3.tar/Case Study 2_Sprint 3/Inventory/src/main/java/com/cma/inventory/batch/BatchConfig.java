package com.cma.inventory.batch;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.cma.inventory.model.Inventory;
import com.cma.inventory.service.InventoryService;

@Configuration
@EnableBatchProcessing
@EnableScheduling
public class BatchConfig{

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    
    @Autowired
    public InventoryService InvtServ;

    @Bean
    public FlatFileItemReader<Inventory> reader() {
        return new FlatFileItemReaderBuilder<Inventory>()
            .name("inventoryItemReader")
            .resource(new ClassPathResource("productMaterData.csv"))
            .delimited()
            .names(new String[]{"productName", "productLabel","inventoryOnHand","minQtyReq","price"})
            .fieldSetMapper(new BeanWrapperFieldSetMapper<Inventory>() {{
                setTargetType(Inventory.class);
            }})
            .build();
    }

    @Bean
    public JdbcBatchItemWriter<Inventory> writer(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Inventory>()
            .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
            .sql("INSERT INTO Inventory (productName,productLabel,inventoryOnHand,minQtyReq,price) VALUES (:productName, :productLabel,:inventoryOnHand,:minQtyReq,:price)")
            .dataSource(dataSource)
            .build();
    }
    
    @Bean
    public Job importUserJob(JobCompleteListener listener, Step step1) {
        return jobBuilderFactory.get("importUserJob")
            .incrementer(new RunIdIncrementer())
            .listener(listener)
            .flow(step1)
            .end()
            .build();
    }

    @Bean
    public Step step1(JdbcBatchItemWriter<Inventory> writer) {
        return stepBuilderFactory.get("step1")
            .<Inventory, Inventory> chunk(10)
            .reader(reader())
            .writer(writer)
            .build();
    }
    
    @Scheduled(cron = "*/5 * * * * *")
	public void perform() throws Exception {
    	List<Inventory> InvtList = InvtServ.getAllInventoryLessThanMin();
    	if(!InvtList.isEmpty()) {
    		for(Inventory invtItem : InvtList) {
    			System.out.println("Task scheduler called for :" + invtItem.getProductName());
    			invtItem.setInventoryOnHand(invtItem.getInventoryOnHand()+invtItem.getMinQtyReq());
    			System.out.println("in hand qty set to : "+invtItem.getInventoryOnHand());
    			InvtServ.updateInventory(invtItem);
    		}
    	}
    		
	}
}