package com.cma.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cma.inventory.messageReceiver.OrderLineItemDTO;
import com.cma.inventory.model.Inventory;
import com.cma.inventory.repository.InventoryRepository;


@Service
public class InventoryService {
	
	@Autowired
	private InventoryRepository InvtRepo;
	
	public List<Inventory> getAllInventory(){
		return InvtRepo.findAll();
	}
	
	public Optional<Inventory> getInventoryId(Long id){
		return InvtRepo.findById(id);
	}
	
	public void deleteAllInventory() {
		InvtRepo.deleteAll();
	}
	
	public boolean deleteInvtById(Long id) {
		Optional<Inventory> i= InvtRepo.findById(id);
		if(i.isPresent()) {
			InvtRepo.deleteById(id);
			return true;
		}
		else
			return false;
	}
	
	public Inventory addInventory(Inventory invt) {
		return InvtRepo.save(invt);
	}
	
	public Inventory updateInventory(Inventory invt) {
        return InvtRepo.save(invt);
	}
	
	public List<Inventory> getAllInventoryLessThanMin(){
		return InvtRepo.getInventoryLessThanMin();
	}
	
	public void updateInventoryQty(OrderLineItemDTO orderLineItemDTO) {
		Optional<Inventory> invt = InvtRepo.findById(orderLineItemDTO.getSkuId());
		if(invt.isPresent()) {
		 invt.get().setInventoryOnHand(invt.get().getInventoryOnHand()-orderLineItemDTO.getItemQty());
		 InvtRepo.save(invt.get());
		}
	}

}
