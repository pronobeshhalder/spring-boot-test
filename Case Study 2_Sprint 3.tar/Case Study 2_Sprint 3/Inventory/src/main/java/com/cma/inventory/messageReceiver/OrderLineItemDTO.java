package com.cma.inventory.messageReceiver;

public class OrderLineItemDTO {
	
	private Long skuId;
	private int itemQty;
	public Long getSkuId() {
		return skuId;
	}
	public void setSkuId(Long skuId) {
		this.skuId = skuId;
	}
	public int getItemQty() {
		return itemQty;
	}
	public void setItemQty(int itemQty) {
		this.itemQty = itemQty;
	}
	
	@Override
	public String toString() {
		return "< Skuid:"+skuId+"itemQty:"+itemQty+" >";
	}
}
