package com.cma.inventory.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cma.inventory.service.InventoryService;
import com.cma.inventory.model.Inventory;

@RestController
public class InventoryController {

	
	@Autowired
	private InventoryService InvtServ;
	
	@RequestMapping(value="/inventory",method=RequestMethod.GET)
	public ResponseEntity<?> getAllInventory(){
		List<Inventory> invtList = new ArrayList<>();
		invtList= InvtServ.getAllInventory();
		if(invtList.isEmpty())
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<List<Inventory>>(invtList,HttpStatus.OK);
	}

	@RequestMapping(value="/inventory/{id}",method = RequestMethod.GET)
	public ResponseEntity<?> getAllInventorybyID(@PathVariable Long id) {
		Optional<Inventory> R = InvtServ.getInventoryId(id);
		return R.isPresent() ?
				new ResponseEntity<Inventory>(R.get(), HttpStatus.OK)
				: new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value="/inventory/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<?> deleteByID(@PathVariable Long id) {
		boolean isDeleted = InvtServ.deleteInvtById(id);
		if(isDeleted)
			return new ResponseEntity<String>(HttpStatus.OK);
		else
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			
	}

	@RequestMapping(value="/inventory", method = RequestMethod.DELETE)
	public void deleteAllInventory() {
		InvtServ.deleteAllInventory();
	}

	@RequestMapping(value="/inventory", method = RequestMethod.POST)
	public ResponseEntity<?> addInventory(@RequestBody Inventory inventory){
		Inventory c= InvtServ.addInventory(inventory);
		if(c != null)
			return new ResponseEntity<Inventory>(c, HttpStatus.CREATED);
		else
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value="/inventory", method = RequestMethod.PUT)
	public ResponseEntity<?> updateInventory(@RequestBody Inventory inventory){
		Inventory c= InvtServ.updateInventory(inventory);
		if(c!=null)
			return new ResponseEntity<Inventory>(c,HttpStatus.OK);
		else
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
}
