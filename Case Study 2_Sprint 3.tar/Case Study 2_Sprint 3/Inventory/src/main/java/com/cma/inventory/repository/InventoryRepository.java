package com.cma.inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cma.inventory.model.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory,Long>{
  
	@Query("select I from Inventory I where I.inventoryOnHand < I.minQtyReq")
	public List<Inventory> getInventoryLessThanMin();
	
	
}
