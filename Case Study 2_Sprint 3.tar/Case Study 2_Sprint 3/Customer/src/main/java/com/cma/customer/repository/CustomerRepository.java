package com.cma.customer.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cma.customer.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>{
	
	 @Transactional
	 List<Customer> findAll();

}
