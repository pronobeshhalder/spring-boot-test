#!/bin/bash
 
export PATH=$PATH:$HOME/.bin/erlang/erts-10.2.3/bin:$HOME/.bin/rmq-server/sbin
rabbitmq-server