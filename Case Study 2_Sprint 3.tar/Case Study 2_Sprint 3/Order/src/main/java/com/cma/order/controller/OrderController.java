package com.cma.order.controller;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cma.order.model.Order;
import com.cma.order.model.OrderDTO;
import com.cma.order.service.OrderService;
import com.cma.order.service.EmailService;

@RestController
public class OrderController {

	@Autowired
	private OrderService orderServ;
	
	@Autowired
	private EmailService EmailService;
	
	@RequestMapping(value="/order",method=RequestMethod.POST)
	public ResponseEntity<?> addOrder(@RequestBody OrderDTO orderdto){
		OrderDTO o = orderServ.addOrder(orderdto);
		if(o != null) {
			EmailService.sendSimpleMessage("amit26.a@tcs.com");
			return new ResponseEntity<OrderDTO>(o, HttpStatus.CREATED);
		}
		else 
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value="/order/customer/{id}",method=RequestMethod.GET)
	public ResponseEntity<?> getAllCustomerOrders(@PathVariable Long id){
		List<OrderDTO> odto = orderServ.getAllOrderByCustID(id);
		if(!odto.isEmpty())
			return new ResponseEntity<List<OrderDTO>>(odto, HttpStatus.OK);
		else 
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value="/order/{id}",method=RequestMethod.GET)
	public ResponseEntity<?> getAllOrdersbyID(@PathVariable Long id){
		List<OrderDTO> odto = orderServ.getAllOrderByOrderID(id);
		if(!odto.isEmpty())
			return new ResponseEntity<List<OrderDTO>>(odto, HttpStatus.OK);
		else 
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
	
	
	@RequestMapping(value="/order}",method=RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<?> updateOrderStatusByID(@RequestBody Order order){
		Order o = orderServ.updateOrderStatusByID(order);
		if(o!=null)
			return new ResponseEntity<Order>(o, HttpStatus.OK);
		else 
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value="/order/{id}",method=RequestMethod.DELETE)
	public void deleteOrderByID(@PathVariable Long id) {
		orderServ.deleteOrderByID(id);
	}
}
