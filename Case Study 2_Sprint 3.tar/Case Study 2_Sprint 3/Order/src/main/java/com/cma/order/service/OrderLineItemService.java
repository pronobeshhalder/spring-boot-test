package com.cma.order.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cma.order.model.OrderLineItem;
import com.cma.order.model.OrderLineItemDTO;
import com.cma.order.repository.OrderLineItemRepository;

@Service
public class OrderLineItemService {
	
	@Autowired 
	private OrderLineItemRepository orderLnItemRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public void addOrderLineItem(OrderLineItem orderitem) {
		orderLnItemRepo.save(orderitem);
	}

	public List<OrderLineItemDTO> getItemListbyOrderID(Long orderId){
		List<OrderLineItemDTO> orderLineItemDTOList = new ArrayList<>();
		 List<OrderLineItem> orderLineItemList = orderLnItemRepo.findByOrderId(orderId);
		 for (OrderLineItem item : orderLineItemList) {
			 OrderLineItemDTO itemDTO = modelMapper.map(item, OrderLineItemDTO.class);
			 orderLineItemDTOList.add(itemDTO);
		 }
		 return orderLineItemDTOList;
	}
	
	public void deleteItemLineByOrderID(Long id) {
		orderLnItemRepo.deleteById(id);
	}
}
