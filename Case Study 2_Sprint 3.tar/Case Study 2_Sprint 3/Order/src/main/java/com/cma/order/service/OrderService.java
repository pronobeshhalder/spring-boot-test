package com.cma.order.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cma.loyalty.model.LoyaltyRequest;
import com.cma.loyalty.model.LoyaltyResponse;
import com.cma.order.messaging.RabbitMQSender;
import com.cma.order.model.*;
import com.cma.order.repository.OrderRepository;
import com.cma.order.service.*;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private OrderLineItemService orderItemserv;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	RabbitMQSender rabbitMQSender;
	
	@Autowired
	LoyaltyService loyaltyService;
	
	public OrderDTO addOrder(OrderDTO orderDto) {
	      Order newOrder = modelMapper.map(orderDto, Order.class);
	      newOrder = orderRepo.save(newOrder);
	      List<OrderLineItemDTO> lineItem = orderDto.getOrderLineItems();
	      convertDTOintoOrderLineItem(lineItem,newOrder.getOrderId());
	      orderDto.setOrderId(newOrder.getOrderId());
	      // Calling Loyalty Service
	      LoyaltyRequest req= new LoyaltyRequest();
	      req.setCustomerId(orderDto.getCustomerId());
	      req.setOrderQuantity(orderDto.getTotalAmount());
	      LoyaltyResponse resp=loyaltyService.getCustomerLoyalty(req);
	      if(null!=resp && resp.getDiscount()>0) {
	    	  System.out.println("The Customer is eligible for "+resp.getDiscount());
	      }
	      return orderDto;
	}
	
	public void convertDTOintoOrderLineItem(List<OrderLineItemDTO> lineItem,Long orderId) {
		
		for (OrderLineItemDTO listOfLineItem : lineItem){
			OrderLineItem orderItem = new OrderLineItem(listOfLineItem.getSkuId(),listOfLineItem.getItemQty(),orderId);
			orderItemserv.addOrderLineItem(orderItem);
			rabbitMQSender.send(listOfLineItem);
			System.out.println("Message sent to RabbitMQ for SkuID : "+ listOfLineItem.getSkuId());
		}
	}
	
	public List<OrderDTO> getAllOrderByCustID(Long id) {
		List<Order> orderListbyId = orderRepo.findByCustomerId(id);
		List<OrderDTO> orderDTOList =  new ArrayList<>();
		List<OrderLineItemDTO> orderLineItemDTOList = new ArrayList<>();
		for(Order orderListbyid : orderListbyId ) {
			orderLineItemDTOList = orderItemserv.getItemListbyOrderID(orderListbyid.getOrderId());
			OrderDTO dtoOrder = modelMapper.map(orderListbyid,OrderDTO.class);
			dtoOrder.setOrderLineItems(orderLineItemDTOList);
			orderDTOList.add(dtoOrder);
		}
		return orderDTOList;
	}
	
	public List<OrderDTO> getAllOrderByOrderID(Long id) {
		List<Order> orderListbyId = orderRepo.findByOrderId(id);
		List<OrderDTO> orderDTOlist =  new ArrayList<>();
		List<OrderLineItemDTO> orderLineItemDTOList = new ArrayList<>();
		for(Order orderListbyid : orderListbyId ) {
			orderLineItemDTOList = orderItemserv.getItemListbyOrderID(orderListbyid.getOrderId());
			OrderDTO dtoorder = modelMapper.map(orderListbyid,OrderDTO.class);
			dtoorder.setOrderLineItems(orderLineItemDTOList);
			orderDTOlist.add(dtoorder);
		}
		return orderDTOlist;
	}
	
	public Order updateOrderStatusByID(Order order) {
		return orderRepo.save(order);
	}
	
	public void deleteOrderByID(Long id) {
		orderRepo.deleteById(id);
		orderItemserv.deleteItemLineByOrderID(id);
	}
}
