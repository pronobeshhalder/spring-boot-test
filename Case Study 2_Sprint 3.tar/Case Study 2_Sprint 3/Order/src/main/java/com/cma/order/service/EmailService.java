package com.cma.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender emailSender;

    public void sendSimpleMessage(String toAddress){
        SimpleMailMessage message = new SimpleMailMessage();
        message.setSubject("Order Confirmation mail");
        message.setText("Order confirmed");
        message.setTo(toAddress);
        message.setFrom("someone@gmail.com");

        emailSender.send(message);
    }

}
