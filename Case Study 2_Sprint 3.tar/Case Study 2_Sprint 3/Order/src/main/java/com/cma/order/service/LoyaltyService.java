package com.cma.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cma.loyalty.model.LoyaltyRequest;
import com.cma.loyalty.model.LoyaltyResponse;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class LoyaltyService {
	private final RestTemplate restTemplate;

	@Autowired
	public LoyaltyService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@HystrixCommand(fallbackMethod = "defaultyLoyalty")
	public LoyaltyResponse getCustomerLoyalty(LoyaltyRequest request) {
		ResponseEntity<LoyaltyResponse> itemResponseEntity = restTemplate.postForEntity("http://localhost:8085/loyalty",
				request,LoyaltyResponse.class);
		if(itemResponseEntity.getStatusCode()==HttpStatus.CREATED) {
			return itemResponseEntity.getBody();
		}
		return null;
	}

	private LoyaltyResponse defaultyLoyalty() {
		LoyaltyResponse response = new LoyaltyResponse();
		response.setDiscount(0);
		return response;

	}
}
