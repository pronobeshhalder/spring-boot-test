{
"customerId":12345,
"paymentChannel":"Debit Card",
"isCod":true,
"orderStatus":"New",
"orderCreatedOn":21122017,
"totalAmount":10000.22,
"shippingAddress":"address 1234",
"orderLineItems" : [
        {
            "skuId":1,
            "itemQty":10
        },
        {
            "skuId":2,
            "itemQty":10
        }
    ]
} // Sample JSON to place the order