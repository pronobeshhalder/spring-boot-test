package com.cma.loyalty.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.cma.loyalty.model.LoyaltyRequest;
import com.cma.loyalty.model.LoyaltyResponse;

@Service("loyaltyService")
public class LoyaltyService {
	private Map<Long,Long> customerLoyaltyMap = new HashMap<Long,Long>();
	
	public LoyaltyResponse calculateLoyalty(LoyaltyRequest request) {
		LoyaltyResponse response= new LoyaltyResponse();
		if(null!=request) {
			if(request.getOrderQuantity() > 10) {
				Long loyaltyPoint=Math.round(request.getOrderQuantity()*.02);
				if(customerLoyaltyMap.containsKey(request.getCustomerId())){
					customerLoyaltyMap.put(request.getCustomerId(),loyaltyPoint+customerLoyaltyMap.get(request.getCustomerId()));
					response.setDiscount(10);
				}else {
					customerLoyaltyMap.put(request.getCustomerId(),loyaltyPoint);
					response.setCuponCode(UUID.randomUUID().toString());
				}
			}
		}
		return response;
	}
	
}
