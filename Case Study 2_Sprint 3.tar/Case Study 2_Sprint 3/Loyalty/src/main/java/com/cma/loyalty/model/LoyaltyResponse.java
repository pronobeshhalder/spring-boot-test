package com.cma.loyalty.model;

public class LoyaltyResponse {
	private String cuponCode;
	private double discount;
	public String getCuponCode() {
		return cuponCode;
	}
	public void setCuponCode(String cuponCode) {
		this.cuponCode = cuponCode;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
}
