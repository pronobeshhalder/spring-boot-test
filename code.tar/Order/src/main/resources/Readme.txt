{
"customerId":12345,
"paymentChannel":"Debit Card",
"isCod":true,
"orderStatus":"New",
"orderCreatedOn":21122017,
"totalAmount":10000.22,
"shippingAddress":"address 1234",
"orderLineItems" : [
        {
            "skuId":1,
            "itemQty":10
        },
        {
            "skuId":2,
            "itemQty":10
        }
    ]
} // Sample JSON to place the order


We need to create below property files in git repo and metion that as config.uri property value in config microservice
1) customerservices.properties and add below line for port
       server.port=8102
            
2) orderservices.properties
      server.port=8101
      spring.rabbitmq.host=127.0.0.1
      spring.rabbitmq.port=5672
      spring.rabbitmq.username=guest
      spring.rabbitmq.password=guest
      order.rabbitmq.exchange=order.exchange
      order.rabbitmq.queue=order.queue
      order.rabbitmq.routingkey=order.routingkey