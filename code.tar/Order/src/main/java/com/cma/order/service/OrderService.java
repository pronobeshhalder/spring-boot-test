package com.cma.order.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cma.order.model.*;
import com.cma.order.repository.OrderRepository;
import com.cma.order.service.*;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private OrderLineItemService orderItemserv;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	public OrderDTO addOrder(OrderDTO orderDto) {
	      Order newOrder = modelMapper.map(orderDto, Order.class);
	      newOrder = orderRepo.save(newOrder);
	      List<OrderLineItemDTO> lineItem = orderDto.getOrderLineItems();
	      convertDTOintoOrderLineItem(lineItem,newOrder.getOrderId());
	      orderDto.setOrderId(newOrder.getOrderId());
	      return orderDto;
	}
	
	public void convertDTOintoOrderLineItem(List<OrderLineItemDTO> lineItem,Long orderid)
	{
			for (OrderLineItemDTO listOfLineItem : lineItem){
			OrderLineItem orderitem = new OrderLineItem(listOfLineItem.getSkuId(),listOfLineItem.getItemQty(),orderid);
			orderItemserv.addOrderLineItem(orderitem);
			System.out.println("Message sent to RabbitMQ for SkuID : "+ listOfLineItem.getSkuId());
		}
	}
	
	public List<OrderDTO> getAllOrderByCustID(Long id) {
		List<Order> orderListbyId = orderRepo.findByCustomerId(id);
		List<OrderDTO> orderDTOlist =  new ArrayList<>();
		List<OrderLineItemDTO> orderLineItemDTOList = new ArrayList<>();
		for(Order orderListbyid : orderListbyId ) {
			orderLineItemDTOList = orderItemserv.getItemListbyOrderID(orderListbyid.getOrderId());
			OrderDTO dtoorder = modelMapper.map(orderListbyid,OrderDTO.class);
			dtoorder.setOrderLineItems(orderLineItemDTOList);
			orderDTOlist.add(dtoorder);
		}
		return orderDTOlist;
	}
	
	public List<OrderDTO> getAllOrderByOrderID(Long id) {
		List<Order> orderListbyId = orderRepo.findByOrderId(id);
		List<OrderDTO> orderDTOlist =  new ArrayList<>();
		List<OrderLineItemDTO> orderLineItemDTOList = new ArrayList<>();
		for(Order orderListbyid : orderListbyId ) {
			orderLineItemDTOList = orderItemserv.getItemListbyOrderID(orderListbyid.getOrderId());
			OrderDTO dtoorder = modelMapper.map(orderListbyid,OrderDTO.class);
			dtoorder.setOrderLineItems(orderLineItemDTOList);
			orderDTOlist.add(dtoorder);
		}
		return orderDTOlist;
	}
	
	public Order updateOrderStatusByID(Order order) {
		return orderRepo.save(order);
	}
	
	public void deleteOrderByID(Long id) {
		orderRepo.deleteById(id);
		orderItemserv.deleteItemLineByOrderID(id);
	}
	
	/*@HystrixCommand( commandKey = "CouponDetails", fallbackMethod = "fallbackCoupon",
    commandProperties= { @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "2000"),
     @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "1")})*/
	/*@HystrixCommand( fallbackMethod = "fallbackCoupon",
	        commandProperties = {
	            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "1000"),
	            @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "1")
	        })*/
	       
	@HystrixCommand(fallbackMethod = "fallbackCoupon")
	public String getCouponCode() throws InterruptedException {
		List<ServiceInstance> instances = discoveryClient.getInstances("zuulservices");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		System.out.println("inside gerCouponCode of order server 1"+baseUrl);
		//URI uri = URI.create("http://127.0.0.1:8102/customer/couponcode/");
		baseUrl = baseUrl + "/customer/customer/couponcode/";
		URI uri = URI.create(baseUrl);
		System.out.println("inside gerCouponCode of order server"+uri.toString());
		String result = this.restTemplate.getForObject(uri, String.class);
		return result;
	}
	
	public String fallbackCoupon() {
		System.out.println("inside fallback method of order server");
		return "DefaultCouponCode";
	}
	
	public Customer getCustomerByID(Long ID) throws InterruptedException {
		List<ServiceInstance> instances = discoveryClient.getInstances("zuulservices");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		System.out.println("inside gerCouponCode of order server 1"+baseUrl);
		//URI uri = URI.create("http://127.0.0.1:8102/customer/couponcode/");
		baseUrl = baseUrl + "/customer/customer/{id}";
		//URI uri = URI.create(baseUrl);
		System.out.println("inside gerCouponCode of order server"+baseUrl);
		Map<String, Object> params = new HashMap<>();
		params.put("id", ID);
		return restTemplate.getForObject(baseUrl, Customer.class, params);
	}
}