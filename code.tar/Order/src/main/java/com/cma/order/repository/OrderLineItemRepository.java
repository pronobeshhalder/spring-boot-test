package com.cma.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cma.order.model.OrderLineItem;
import java.lang.Long;
import java.util.List;

public interface OrderLineItemRepository extends JpaRepository<OrderLineItem,Long> {

	List<OrderLineItem> findByOrderId(Long orderid);
}
