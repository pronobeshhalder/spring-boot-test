package com.cma.order.messaging;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cma.order.model.OrderLineItemDTO;

@Service
public class RabbitMQSender {

	@Autowired
	private AmqpTemplate rabbitTemplate;
	
	@Value("${order.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${order.rabbitmq.routingkey}")
	private String routingkey;	
	
	public void send(OrderLineItemDTO orderItem) {
		rabbitTemplate.convertAndSend(exchange, routingkey, orderItem);
		System.out.println("Send msg = " + orderItem);
	}
}
