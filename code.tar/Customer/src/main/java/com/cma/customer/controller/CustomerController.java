package com.cma.customer.controller;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cma.customer.model.Customer;
import com.cma.customer.service.CustomerService;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@RestController
public class CustomerController {
	
	
	@Autowired
	private CustomerService custServ;
	
	@RequestMapping(value = "/customer/", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public List<Customer> getAllCustomers(){
		return custServ.getAllCustomers();
	}
	
	@RequestMapping(value = "/customer/{id}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Optional<Customer> getCustomerById(@PathVariable Long id){
		return custServ.getCustomerbyId(id);
	}
	
	@RequestMapping(value = "/customer/", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public Customer addCustomer(@RequestBody Customer cust){
		return custServ.addCustomer(cust);
	}
	
	@RequestMapping(value = "/customer/{id}", method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	public Customer updateCustomer(@RequestBody Customer cust, @PathVariable Long id){
		return custServ.updateCustomer(cust, id);
	}
	
	@RequestMapping(value = "/customer/{id}", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public void deleteCustomerById(@PathVariable Long id){
		custServ.deleteCustomerById(id);
	}
	
	@RequestMapping(value = "/customer/", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public void deleteCustomers(){
		custServ.deleteCustomers();
	}
	
	@RequestMapping(value = "/customer/couponcode/", method = RequestMethod.GET)
	public String getCouponCode() throws InterruptedException{
		//Thread.sleep(10000);
		return "couponCode";
	}
}