package com.cma.customer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cma.customer.exception.NoSuchResourceFoundException;
import com.cma.customer.model.Customer;
import com.cma.customer.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository custReposit;
	
    public List<Customer> getAllCustomers() {
		List<Customer> allCusts = custReposit.findAll();
		if(allCusts.isEmpty() || allCusts == null) {
			throw new NoSuchResourceFoundException("No customers are present");
		}
        return allCusts;
    }
	
	public Optional<Customer> getCustomerbyId(Long id) {
		Optional<Customer> custById = custReposit.findById(id);
		if(!custById.isPresent()) {
			throw new NoSuchResourceFoundException("No customer is present");
		}
		return custById;
	}
	
	public Customer addCustomer(Customer cust) {
	    return custReposit.save(cust);
	}
	
	public Customer updateCustomer(Customer cust, Long id) {
		Customer updtCust = custReposit.save(cust);
		if(updtCust == null) {
			throw new NoSuchResourceFoundException("No customer is present");
		}
	    return updtCust;
	}
	
	public void deleteCustomerById(Long id) {
		Optional<Customer> c = custReposit.findById(id);
		if(!c.isPresent()) {
			throw new NoSuchResourceFoundException("No customer is present");
		} else {
			custReposit.deleteById(id);
		}
	}
	
	public void deleteCustomers() {
		custReposit.deleteAll();
	}
}